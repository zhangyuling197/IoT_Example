function s = belief2str(Y)

if isempty(Y)
    s = '{}';
    return;
end

parts = cell(1,size(Y,1));
for i = 1:size(Y,1)
    x = Y(i,1)-1;   
    f = Y(i,2);

    if f == 1
        parts{i} = sprintf('%dF', x);
    else
        parts{i} = sprintf('%dN', x);
    end
end

s = ['{' strjoin(parts, ',') '}'];
end
