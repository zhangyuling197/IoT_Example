function delta = build_delta_map(Td)
    delta = containers.Map('KeyType', 'int32', 'ValueType', 'any');

    % 遍历转移表（每行表示一段转移）
    for r = 1:size(Td, 1)
        src = int32(Td(r, 1));
        dst = int32(Td(r, 3));
        event = Td(r, 2);

        % 确保事件键格式一致（转换为字符串）
        if isnumeric(event)
            event = sprintf('event_%d', event);
        end

        % 初始化子映射
        if ~isKey(delta, src)
            delta(src) = containers.Map('KeyType', 'char', 'ValueType', 'int32');
        end

        delta(src)(event) = dst;
        fprintf('Mapping added: src %d -- %s --> dst %d\n', src, event, dst);
    end
end