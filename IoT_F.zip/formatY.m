function s = formatY(Yq)
% Yq is |Y| x 2 matrix: [state , fault_flag]

items = cell(size(Yq,1),1);

for i = 1:size(Yq,1)
    x = Yq(i,1);
    f = Yq(i,2);
    if f == 0
        items{i} = sprintf('%dN', x);
    else
        items{i} = sprintf('%dF', x);
    end
end

s = ['{', strjoin(items, ','), '}'];
end
