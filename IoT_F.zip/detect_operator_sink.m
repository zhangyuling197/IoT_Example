function sink = detect_operator_sink(G_opr)
% Detect operator sink state (0-based) for G_opr = {n, Ed, Td, init, ...}

    Td = G_opr{3};
    n  = G_opr{1};

    sink = -1;

    % 1) dead-end candidates (no outgoing)
    hasOut = false(1,n);
    if ~isempty(Td)
        hasOut(unique(Td(:,1)+1)) = true;
    end
    deadEnd = find(~hasOut) - 1;
    if ~isempty(deadEnd)
        sink = deadEnd(end);   % prefer highest index
        return;
    end

    % 2) self-loop-only
    % for q = n-1:-1:0
    %     rows = Td(Td(:,1)==q, :);
    %     if ~isempty(rows) && all(rows(:,3)==q)
    %         sink = q; return;
    %     end
    % end

    % 3) fallback (if your model guarantees a sink at the end)
    sink = n - 1;
end
