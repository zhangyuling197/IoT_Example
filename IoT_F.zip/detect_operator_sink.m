function sink = detect_operator_sink(G_opr)

    Td = G_opr{3};
    n  = G_opr{1};

    sink = -1;

    
    hasOut = false(1,n);
    if ~isempty(Td)
        hasOut(unique(Td(:,1)+1)) = true;
    end
    deadEnd = find(~hasOut) - 1;
    if ~isempty(deadEnd)
        sink = deadEnd(end);   
        return;
    end

    sink = n - 1;
end
