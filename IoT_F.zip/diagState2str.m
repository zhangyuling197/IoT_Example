function s = diagState2str(Yq)
% Yq is a diagnoser state, e.g. [3 0; 7 1]

if isempty(Yq)
    s = '{}';
    return;
end

elems = strings(1, size(Yq,1));
for i = 1:size(Yq,1)
    x = Yq(i,1);
    f = Yq(i,2);
    if f == 0
        elems(i) = num2str(x);
    else
        elems(i) = sprintf('%dF', x);
    end
end

s = ['{', strjoin(elems, ','), '}'];
end
