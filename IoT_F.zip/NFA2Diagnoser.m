function Gdiag = NFA2Diagnoser(Gn, Sigma_o, fault_event)


X0 = Gn.X0;
T  = Gn.T;

% ================= initial =====================
y0 = UR_diag([X0(:) 0], T, fault_event, Sigma_o);  % 

Y = {y0};          
queue = 1;         
Td = [];           % diagnoser transitions

% ================= BFS construction ===================
while queue <= length(Y)
    y = Y{queue};

    for k = 1:numel(Sigma_o)
        e = Sigma_o(k);   
        y_next = diagnoserStep(y, e, T, fault_event, Sigma_o);

        if isempty(y_next)
            continue;
        end

        idx = findBelief(Y, y_next);
        if idx == 0
            Y{end+1} = y_next;
            idx = length(Y);
        end

        Td(end+1,:) = [queue, e, idx];
    end

    queue = queue + 1;
end

% ================= output automaton ===================
Gdiag.X     = 1:length(Y);
Gdiag.X0    = 1;
Gdiag.Sigma = Sigma_o;
Gdiag.T     = Td;
Gdiag.Y     = Y;

end

function Y = UR_diag(Y0, T, fault_event, Sigma_o)

Y = unique(Y0,'rows');
changed = true;

while changed
    changed = false;

    for i = 1:size(Y,1)
        x = Y(i,1);
        f = Y(i,2);

        idx = find(T(:,1)==x);
        for k = idx'
            e = T(k,2);

            % unobservable event
            if ismember(e, Sigma_o)
                continue;
            end

            x2 = T(k,3);
            f2 = f || any(e == fault_event);  
            new = [x2 f2];

            if ~ismember(new, Y, 'rows')
                Y = [Y; new];
                changed = true;
            end
        end
    end
end
end
function y_next = diagnoserStep(y, e, T, fault_event, Sigma_o)

post = [];

for i = 1:size(y,1)
    x = y(i,1);
    f = y(i,2);

    idx = find(T(:,1)==x & T(:,2)==e);
    for k = idx'
        x2 = T(k,3);
        f2 = f | (e == fault_event);  
        post(end+1,:) = [x2 f2];
    end
end

y_next = UR_diag(post, T, fault_event, Sigma_o);
end
