function [n, Ed, Td, x0] = unpack_auto(G)
% Robust unpacker for struct/cell automaton
% 从自动机结构中解包信息，包括:
% n: 状态数, Ed: 字母表(事件集), Td: 转移矩阵, x0: 初始状态

% 初始化参数
x0 = [];  % 初始状态

if iscell(G) % 如果 G 为一个 Cell 数组
    n = G{1}; Ed = G{2}; Td = G{3};
    if numel(G) >= 4
        x0 = G{4}; % 若初始状态信息存在则赋值
    end
elseif isstruct(G) % 如果 G 为一个结构体
    % 状态数 n
    if isfield(G,'n')
        n = G.n;
    elseif isfield(G,'X')
        n = numel(G.X);
    elseif isfield(G,'Y')
        n = numel(G.Y);
    else
        n = max(G.T(:,[1 3]), [], 'all');
    end

    % 事件集 Ed (字母表)
    if isfield(G,'alphabet')
        Ed = G.alphabet;
    elseif isfield(G,'Sigma')
        Ed = G.Sigma;
    elseif isfield(G,'Ed')
        Ed = G.Ed;
    else
        error('unpack_auto: alphabet (事件集) not found in G');
    end

    % 转移矩阵 Td
    if isfield(G,'T')
        Td = G.T;
    else
        error('unpack_auto: transitions (T) not found in G');
    end

    % 初始状态 x0
    if isfield(G,'init')
        x0 = G.init;
    elseif isfield(G,'x0')
        x0 = G.x0;
    elseif isfield(G,'X0')
        x0 = G.X0;
    else
        x0 = 1; % 默认将初始状态设为状态 1
    end
else
    error('unpack_auto: Unsupported input type for G');
end

% 确保数据类型规范化
Td = double(Td); % 转换为双精度类型
Ed = normalize_alphabet(Ed); % 字母表标准化
end

function Ed = normalize_alphabet(Ed)
% 字母表数据类型标准化
if isnumeric(Ed)
    Ed = num2cell(Ed);
elseif ischar(Ed)
    Ed = arrayfun(@(c){c}, Ed);
elseif isstring(Ed)
    Ed = cellstr(Ed);
end
end