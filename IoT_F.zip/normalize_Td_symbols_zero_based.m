function G = normalize_Td_symbols_zero_based(G)
% 接受 cell {n,Ed,Td,...} 或 struct .n,.alphabet,.T

    if iscell(G)
        Ed = G{2}; Td = G{3};
        if max(Td(:,2)) >= numel(Ed)    
            Td(:,2) = Td(:,2) - 1;
        end
        G{3} = Td;
    else
        Ed = G.alphabet; Td = G.T;
        if max(Td(:,2)) >= numel(Ed)
            Td(:,2) = Td(:,2) - 1;
        end
        G.T = Td;
    end
end
