function [Qn, Qc, Qu, Q_sink, Qd, Qe, Qwe] = ComputeJointState(GJ, G_att, G_opr, Sigma_o_idx, Sigma_ins_idx, Sigma_era_idx)
% Compute joint state classification and weakly exposing states
% GJ: joint observer
% G_att, G_opr: attacker/operator automata
% Sigma_*_idx: indices for observable, insertion, erasable events
% Outputs: Qn, Qc, Qu, Q_sink, Qd, Qe, Qwe

jointPairs = GJ.jointMap;  % nJ x 2
nJ = size(jointPairs,1);

Qn = false(nJ,1); Qc = false(nJ,1); Qu = false(nJ,1);
Q_sink = false(nJ,1); Qd = false(nJ,1);
Qe = false(nJ,1); Qwe = false(nJ,1);

% --- Helper ternary ---
ternary = @(cond,valTrue,valFalse) ifelse(cond,valTrue,valFalse);
is_opr_sink = @(q) isfield(G_opr,'sink') && q==G_opr.sink;

% --- classify Qn, Qc, Qu, Q_sink ---
for idx = 1:nJ
    qa = jointPairs(idx,1); qo = jointPairs(idx,2);

    if is_opr_sink(qo)
        Q_sink(idx) = true;
        continue;
    end

    att_set = G_att.Y{qa}; 
    opr_set = G_opr.Y{qo};
    if isvector(att_set) && size(att_set,2)==1, att_set = [att_set, zeros(numel(att_set),1)]; end
    if isvector(opr_set) && size(opr_set,2)==1, opr_set = [opr_set, zeros(numel(opr_set),1)]; end

    att_labels = att_set(:,2); opr_labels = opr_set(:,2);

    if all(att_labels==0) && all(opr_labels==0)
        Qn(idx) = true;
    elseif all(att_labels==1) && all(opr_labels==1)
        Qc(idx) = true;
    else
        Qu(idx) = true;
    end
end

%% --- compute Qd ---
Ea = 1:numel(G_att.Sigma);
T = GJ.T;
att_normal_idx = false(numel(G_att.Y),1);
for qa = 1:numel(G_att.Y)
    att_set = G_att.Y{qa};
    if isvector(att_set) && size(att_set,2)==1, att_set = [att_set, zeros(numel(att_set),1)]; end
    att_labels = att_set(:,2);
    att_normal_idx(qa) = all(att_labels==0);
end

for idx = find(Qn)'
    trans_idx = find(T(:,1)==idx);
    for t = trans_idx'
        e = T(t,2); if ~ismember(e,Ea), continue; end
        q_next = T(t,3);
        if ~Qn(q_next)
            q_next_att = jointPairs(q_next,1);
            if ~att_normal_idx(q_next_att)
                Qd(idx) = true; break;
            end
        end
    end
end

%% --- compute Qe (=Q_sink) ---
Qe = Q_sink;

%% --- compute Qwe (weakly exposing) ---
Qwe = Qe;
changed = true;
n = nJ;
delta = cell(n,1);
for r = 1:size(T,1)
    s = T(r,1); a = T(r,2); t = T(r,3);
    if isempty(delta{s})
        delta{s} = containers.Map('KeyType','int32','ValueType','int32');
    end
    delta{s}(int32(a)) = t;
end

isEra = false(1,numel(GJ.Sigma));
isEra(Sigma_era_idx) = true;

minusIdx = -ones(1,numel(GJ.Sigma));
for ii = Sigma_o_idx(:)'
    for k = 1:numel(GJ.Sigma)
        if strcmp(GJ.Sigma{k}, [GJ.Sigma{ii}, '_-'])
            minusIdx(ii) = k; break;
        end
    end
end

while changed
    Qwe_new = Qwe;
    for q = 1:n
        if Qwe(q), continue; end

        % (1) observable condition
        ok1 = false;
        for e = Sigma_o_idx(:)'
            if ~isempty(delta{q}) && isKey(delta{q},int32(e))
                t = delta{q}(int32(e));
                if Qwe(t)
                    if ~isEra(e), ok1 = true; break;
                    else
                        em = minusIdx(e);
                        if em>0 && isKey(delta{q},int32(em)) && Qwe(delta{q}(int32(em)))
                            ok1 = true; break;
                        end
                    end
                end
            end
        end
        if ~ok1, continue; end

        % (2) insertion condition
        ok2 = true;
        for ep = Sigma_ins_idx(:)'
            if isempty(delta{q}) || ~isKey(delta{q},int32(ep)) || ~Qwe(delta{q}(int32(ep)))
                ok2 = false; break;
            end
        end

        if ok1 && ok2
            Qwe_new(q) = true;
        end
    end
    changed = any(Qwe_new ~= Qwe);
    Qwe = Qwe_new;
end

%% --- helper: format joint state ---
function s = format_joint(idx)
    qa = jointPairs(idx,1); qo = jointPairs(idx,2);

    % attacker
    att_set = G_att.Y{qa};
    if isvector(att_set) && size(att_set,2)==1, att_set = [att_set, zeros(numel(att_set),1)]; end
    att_cell = cell(size(att_set,1),1);
    for k = 1:size(att_set,1)
        att_cell{k} = sprintf('%d%s', att_set(k,1), ternary(att_set(k,2)==1,'F','N'));
    end
    att_str = ['{' strjoin(att_cell,',') '}'];

    % operator
    if Q_sink(idx)
        opr_str = '{sink}';
    else
        opr_set = G_opr.Y{qo};
        if isvector(opr_set) && size(opr_set,2)==1, opr_set = [opr_set, zeros(numel(opr_set),1)]; end
        opr_cell = cell(size(opr_set,1),1);
        for k = 1:size(opr_set,1)
            opr_cell{k} = sprintf('%d%s', opr_set(k,1), ternary(opr_set(k,2)==1,'F','N'));
        end
        opr_str = ['{' strjoin(opr_cell,',') '}'];
    end

    s = sprintf('%s ; %s', att_str, opr_str);
end

%% --- print results ---
% fprintf('--- Normal joint states Qn ---\n');
% for idx = find(Qn)', fprintf('%s\n', format_joint(idx)); end
% 
% fprintf('--- Certain joint states Qc ---\n');
% for idx = find(Qc)', fprintf('%s\n', format_joint(idx)); end
% 
% fprintf('--- Uncertain joint states Qu ---\n');
% for idx = find(Qu)', fprintf('%s\n', format_joint(idx)); end
% 
% fprintf('--- Operator-sink joint states Q_sink ---\n');
% for idx = find(Q_sink)', fprintf('%s\n', format_joint(idx)); end
% 
% fprintf('--- Q_d joint states ---\n');
% for idx = find(Qd)', fprintf('%s\n', format_joint(idx)); end
% 
% fprintf('--- Qe (initial exposing = Q-sink) ---\n');
% for idx = find(Qe)', fprintf('%s\n', format_joint(idx)); end
% 
% fprintf('--- Qwe (weakly exposing) ---\n');
% for idx = find(Qwe)', fprintf('%s\n', format_joint(idx)); end
% 
% fprintf('Number of normal joint states Qn: %d\n', sum(Qn));
% fprintf('Number of certain joint states Qc: %d\n', sum(Qc));
% fprintf('Number of uncertain joint states Qu: %d\n', sum(Qu));
% fprintf('Number of operator-sink joint states Q_sink: %d\n', sum(Q_sink));
% fprintf('Number of Q_d states: %d\n', sum(Qd));
% fprintf('Number of Qe states: %d\n', sum(Qe));
% fprintf('Number of Qwe states: %d\n', sum(Qwe));

end

%% --- simple ternary helper ---
function out = ifelse(cond,a,b)
    if cond, out=a; else, out=b;
    end
end
