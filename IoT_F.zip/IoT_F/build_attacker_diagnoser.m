function G_att = build_attacker_diagnoser(Gdiag, Gn, Sigma_o, Sigma_ins, Sigma_era)

nd = numel(Gdiag.Y);

G_att.X  = 1:nd;
G_att.X0 = Gdiag.X0;
G_att.Y  = Gdiag.Y;
G_att.n  = nd;

Td = Gdiag.T;

%% ---------- Build Sigma_a = Sigma_o ∪ Sigma_ins ∪ Sigma_era ----------
Sigma = {};

% 1. observable events only
for k = Sigma_o(:)'
    Sigma{end+1} = Gn.Sigma{k};
end

% 2. insertion events e+
for k = Sigma_ins(:)'
    Sigma{end+1} = [Gn.Sigma{k} '+'];
end

% 3. deletion events e-
for k = Sigma_era(:)'
    Sigma{end+1} = [Gn.Sigma{k} '-'];
end

G_att.Sigma = Sigma;

%% ---------- Build transitions ----------
T_att = [];

% ---- normal observable transitions ----
for r = 1:size(Td,1)
    src = Td(r,1);
    sym = Td(r,2);   % index in Gn.Sigma
    dst = Td(r,3);

    % only observable events are modeled
    if ismember(sym, Sigma_o)
        ename = Gn.Sigma{sym};
        sym_idx = find(strcmp(G_att.Sigma, ename), 1);
        T_att(end+1,:) = [src, sym_idx, dst];
    end

    % erasable observable event → a-
    if ismember(sym, Sigma_era)
        ename = [Gn.Sigma{sym} '-'];
        sym_minus = find(strcmp(G_att.Sigma, ename), 1);
        T_att(end+1,:) = [src, sym_minus, dst];
    end
end

% ---- insertion events e+ are self-loops ----
for k = Sigma_ins(:)'
    ename = [Gn.Sigma{k} '+'];
    sym_plus = find(strcmp(G_att.Sigma, ename), 1);
    for q = 1:nd
        T_att(end+1,:) = [q, sym_plus, q];
    end
end

% ---- remove duplicates ----
G_att.T = unique(T_att, 'rows', 'stable');

end
