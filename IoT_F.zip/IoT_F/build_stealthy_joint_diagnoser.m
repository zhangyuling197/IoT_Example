function GSJ = build_stealthy_joint_diagnoser(GJ, jointMap, sink_opr_list, Sigma_o_idx, Sigma_ins_idx, Sigma_era_idx)
% Build stealthy joint diagnoser GSJ, remove weakly exposing states

Ed = GJ.Sigma;
Td = GJ.T;
if isempty(Td), Td = zeros(0,3); end
init = 1;

numStates = size(jointMap,1);

% 构建 delta 映射
delta = cell(numStates,1);
for r = 1:size(Td,1)
    s = Td(r,1); a = Td(r,2); t = Td(r,3);
    if s > numStates || t > numStates, continue; end
    if isempty(delta{s})
        delta{s} = containers.Map('KeyType','int32','ValueType','int32');
    end
    delta{s}(int32(a)) = t;
end

% Qe = operator-sink
Qe = false(1,numStates);
for q = 1:numStates
    if ismember(jointMap(q,2), sink_opr_list)
        Qe(q) = true;
    end
end

% compute weakly exposing Qwe
Qwe = Qe;
changed = true;

succList = cell(1,numStates);
for q = 1:numStates
    succ = [];
    if ~isempty(delta{q})
        keys = delta{q}.keys;
        for k = 1:numel(keys)
            t = delta{q}(keys{k});
            if t <= numStates
                succ(end+1,1) = t; % 列向量
            end
        end
    end
    succList{q} = succ;
end

while changed
    changed = false;
    for q = 1:numStates
        if Qwe(q), continue; end
        succ = succList{q};
        if isempty(succ), continue; end
        if all(Qwe(succ))
            Qwe(q) = true;
            changed = true;
        end
    end
end

% 保留非 weakly exposing 状态
keep = find(~Qwe);
if isempty(keep)
    GSJ = {0, Ed, zeros(0,3), [], [], struct()};
    return;
end

% 过滤 Td 中的转移
rows = Td(ismember(Td(:,1),keep) & ismember(Td(:,3),keep),:);

% 构建 old2new 映射
old2new = zeros(1,numStates);
old2new(keep) = 1:numel(keep);

% 确保 Td_new 格式正确，逐行赋值避免维度问题
Td_new = zeros(size(rows,1),3);
for i = 1:size(rows,1)
    Td_new(i,:) = [old2new(rows(i,1)), rows(i,2), old2new(rows(i,3))];
end

% 输出 GSJ
GSJ = {numel(keep), Ed, Td_new, old2new(init), [], struct( ...
    'jointMap', jointMap(keep,:), 'old2new', old2new)};
end
