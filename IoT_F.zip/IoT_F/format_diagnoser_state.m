function s = format_diagnoser_state(Yq)


labels = {};


if isstruct(Yq)
    if isfield(Yq,'N')
        for x = Yq.N
            labels{end+1} = sprintf('%dN', x);
        end
    end
    if isfield(Yq,'F')
        for x = Yq.F
            labels{end+1} = sprintf('%dF', x);
        end
    end


elseif iscell(Yq) && numel(Yq) == 2 && isnumeric(Yq{1})
    for x = Yq{1}
        labels{end+1} = sprintf('%dN', x);
    end
    for x = Yq{2}
        labels{end+1} = sprintf('%dF', x);
    end


elseif isnumeric(Yq)
    for x = Yq
        labels{end+1} = sprintf('%dN', x);
    end
else
    s = '∅';
    return;
end

if isempty(labels)
    s = '∅';
else
    s = strjoin(labels, ',');
end
end
