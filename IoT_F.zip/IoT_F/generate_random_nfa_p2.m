function Gn_list = generate_random_nfa_p2(num_examples, n_range, m_range, p_obs, p_ins, p_era, savefile)


rng(345);  
Gn_list = cell(1,num_examples);

e = 0;   
trial = 0;

while e < num_examples
    trial = trial + 1;

    %% ---------- 状态数 & 事件数 ----------
    n = randi([n_range(1), n_range(2)]);
    m0 = randi([m_range(1), m_range(2)]);   
    m  = max(2, m0);

    %% ---------- 事件集----------
    non_fault_count = m-1;
    E_cell = cell(1, non_fault_count + 1);

    char_idx = 0;
    for i = 1:non_fault_count
        c = char('a' + char_idx);
        if c == 'f'
            char_idx = char_idx + 1;
            c = char('a' + char_idx);
        end
        E_cell{i} = c;
        char_idx = char_idx + 1;
    end
    E_cell{end} = 'f';
    f_idx = numel(E_cell);
    m = numel(E_cell);

    %% ---------- 可观事件（不含 f） ----------
    n_obs = max(2, round(p_obs*(m-1))); % 至少2个可观事件
    idx_obs = randperm(m-1, min(n_obs, m-1));
    Sigma_o_cell = E_cell(idx_obs);
    Sigma_o_idx  = idx_obs;

    %% ---------- 插入 / 删除事件 ----------
    n_ins = min(round(p_ins*numel(Sigma_o_cell)), numel(Sigma_o_cell));
    n_era = min(round(p_era*numel(Sigma_o_cell)), numel(Sigma_o_cell));
    Sigma_ins = Sigma_o_cell(randperm(numel(Sigma_o_cell), n_ins));
    Sigma_era = Sigma_o_cell(randperm(numel(Sigma_o_cell), n_era));

    %% ---------- 不可观事件索引（含 f） ----------
    Sigma_u_idx = setdiff(1:m, Sigma_o_idx);

    %% ---------- 初始状态 ----------
    X0 = 1;  % 固定初始状态为1
    Xm = [];

    %% ---------- 随机转移生成 ----------
    T = [];
    rho = 0.3;

    for src = 1:n
        for a = 1:(m-1)   
            if rand < rho
                k = randi([1 2]);
                if ismember(a, Sigma_u_idx)
                    % 不可观事件：前向无环
                    if src < n
                        dst_candidates = (src+1):n;
                        dst = dst_candidates(randperm(numel(dst_candidates), ...
                              min(k, numel(dst_candidates))));
                    else
                        continue;
                    end
                else
                    % 可观事件：任意状态
                    dst = randperm(n, k);
                end
                T = [T; repmat(src,numel(dst),1), repmat(a,numel(dst),1), dst(:)];
            end
        end
    end

    %% ---------- 唯一故障转移（不可观，前向） ----------
    src_f = randi([2, n-1]);  
    dst_f = randi([src_f+1, n]);
    T = [T; src_f, f_idx, dst_f];


    %% ---------- 保证所有状态从初始状态可达 ----------
    if ~is_weakly_connected_pure(n, T)
        backbone = [(1:n-1)', ones(n-1,1), (2:n)'];
        T = [T; backbone];
    end
    
    obs_idx = Sigma_o_idx;
    if isempty(intersect(T(T(:,1)==X0,2), obs_idx))
        a = obs_idx(randi(numel(obs_idx)));
        dst = randi(n);
        T = [T; X0, a, dst];
    end

    %% ---------- 保证语言活性 ----------
    for s = 1:n
        out_edges = find(T(:,1) == s);
        if isempty(out_edges)
            a = randi(m-1);
            if ismember(a, Sigma_u_idx)
                if s < n
                    dst_candidates = (s+1):n;
                    dst = dst_candidates(randi(numel(dst_candidates)));
                else
                    dst = n;
                end
            else
                dst = randi(n);
            end
            T = [T; s, a, dst];
        end
    end

    %% ---------- 合法化 & 去重 ----------
    T(:,1) = max(1, min(n, T(:,1)));
    T(:,2) = max(1, min(m, T(:,2)));
    T(:,3) = max(1, min(n, T(:,3)));
    T = unique(T, 'rows');

    %% ---------- 构造 Gn ----------
    Gn.n     = n;
    Gn.X     = 1:n;
    Gn.Sigma = E_cell;
    Gn.T     = T;
    Gn.X0    = X0;
    Gn.Xm    = Xm;

    %% ---------- A3----------
    Gdiag = NFA2Diagnoser(Gn, Sigma_o_idx, f_idx);

    nDiag = numel(Gdiag.Y);  

if ~is_nominally_prognosable_A3(Gn, Sigma_o_idx, f_idx) || nDiag < 2 || nDiag > 50
    continue;   
end


  
    e = e + 1;
    Gn_list{e} = { ...
        n, ...
        E_cell, ...
        T, ...
        X0, ...
        Xm, ...
        Sigma_o_cell, ...
        Sigma_ins, ...
        Sigma_era ...
    };

    fprintf('[Sample %d | trial %d] n=%d, |T|=%d, |Sigma_o|=%d, |Sigma_ins|=%d, |Sigma_era|=%d\n', ...
        e, trial, n, size(T,1), numel(Sigma_o_cell), numel(Sigma_ins), numel(Sigma_era));
end

%% ---------- 可选保存 ----------
if nargin >= 7 && ~isempty(savefile)
    Gn_full = Gn_list; 
    save(savefile, 'Gn_full');
end
end

% =====================================================
function tf = is_weakly_connected_pure(n, T)
    adj = cell(n,1);
    for i = 1:n
        adj{i} = [];
    end

    for r = 1:size(T,1)
        u = T(r,1);
        v = T(r,3);
        if u ~= v
            adj{u} = unique([adj{u}, v]);
            adj{v} = unique([adj{v}, u]);
        end
    end

    vis = false(1,n);
    q = 1;
    vis(1) = true;
    head = 1;

    while head <= numel(q)
        x = q(head);
        head = head + 1;
        for y = adj{x}
            if ~vis(y)
                vis(y) = true;
                q(end+1) = y; 
            end
        end
    end

    tf = all(vis);
end


function ok = is_nominally_prognosable_A3(Gn, Sigma_o_idx, f_idx)
Gdiag = NFA2Diagnoser(Gn, Sigma_o_idx, f_idx);
Y = Gdiag.Y;  
T = Gdiag.T;  

n = numel(Y);


isCertain = false(n,1);
for i = 1:n
    Yi = Y{i};
    if isempty(Yi)
        continue;
    end
    Yi = Yi(:,1);        
    isCertain(i) = all(Yi ~= f_idx);
end

% 标记非确定状态：包含混合N/F的状态
isUncertain = false(n,1);
for i = 1:n
    Yi = Y{i};
    if isempty(Yi)
        continue;
    end
    Yi = Yi(:,1);       
    hasFaulty    = any(Yi == f_idx);
    hasNonFaulty = any(Yi ~= f_idx);
    hasFaulty    = logical(hasFaulty);
    hasNonFaulty = logical(hasNonFaulty);
    if hasFaulty && hasNonFaulty
        isUncertain(i) = true;
    end
end


if isempty(T)
    ok = true;
    return;
end


G = digraph(T(:,1), T(:,3));

ok = true; 

for i = 1:n
    if ~isUncertain(i)
        continue;  
    end

    % 找到该非确定状态的所有前继 diagnoser 状态
    pred_idx = predecessors(G, i)';
    if isempty(pred_idx)
        continue;
    end

    for p = pred_idx
        % 从前继状态出发的可达部分
        reachable = bfsearch(G, p);
        reachable = unique(reachable);

        % 查看是否包含某个 certain state
        certain_in_reachable = reachable(isCertain(reachable));

        for cs = certain_in_reachable'
            % 检查从该 certain state 是否存在环
            dfs_res = dfsearch(G, cs, 'Restart', cs);
            if any(dfs_res == cs)
                % 找到环，NFA不可预测
                ok = false;
                return;
            end
        end
    end
end

end
