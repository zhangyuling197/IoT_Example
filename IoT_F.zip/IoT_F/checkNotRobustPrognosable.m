function [isNotRobust, badCycle] = checkNotRobustPrognosable(GJ, Qc, Qd, Ea, G_att, G_opr)

T  = GJ.T;              
nJ = numel(GJ.X);

isNotRobust = false;
badCycle    = [];

for q0 = find(Qd)'      % ∃ q ∈ Qd
    visited = false(nJ,1);
    onstack = false(nJ,1);
    parent  = zeros(nJ,1);

    if dfs(q0)
        isNotRobust = true;
        
        return;
    end
end

    function found = dfs(q)
        visited(q) = true;
        onstack(q) = true;
        found = false;

        % attacker-observable transitions only
        trans = find(T(:,1)==q & ismember(T(:,2), Ea));

        for k = trans'
            qn = T(k,3);

            if ~visited(qn)
                parent(qn) = q;
                if dfs(qn)
                    found = true;
                    return;
                end
            elseif onstack(qn)
                % ===== cycle detected =====
                cycle = qn;
                cur   = q;
                while cur ~= qn && cur ~= 0
                    cycle(end+1) = cur; %#ok<AGROW>
                    cur = parent(cur);
                end
                cycle = fliplr(cycle);  % natural order

                % ===== check theorem condition =====
                if any(~Qc(cycle))
                    badCycle = cycle;
                    found = true;
                    return;
                end
            end
        end

        onstack(q) = false;
    end

end

%% ================= helper: print cycle =================
function printBadCycle(cycle, GJ, G_att, G_opr)
fprintf('===== Bad Cycle =====\n');
for k = 1:length(cycle)
    idx = cycle(k);
    att_idx = GJ.jointMap(idx,1);
    opr_idx = GJ.jointMap(idx,2);
    att_str = formatState(G_att.Y{att_idx});
    opr_str = formatState(G_opr.Y{opr_idx});
    fprintf('{%s} ; {%s}\n', att_str, opr_str);
end
fprintf('===================\n');

    function s = formatState(Ystate)
        s_cell = {};
        if isnumeric(Ystate) && size(Ystate,2)>=2
            for i = 1:size(Ystate,1)
                x = Ystate(i,1);
                flag = Ystate(i,2);
                if flag==1
                    s_cell{end+1} = sprintf('%dF', x);
                else
                    s_cell{end+1} = sprintf('%dN', x);
                end
            end
        elseif isnumeric(Ystate)
            Ystate = Ystate(Ystate~=0);
            for i = 1:numel(Ystate)
                s_cell{end+1} = sprintf('%dN', Ystate(i));
            end
        elseif iscell(Ystate)
            s_cell = cellfun(@(x) sprintf('%s', x), Ystate, 'UniformOutput', false);
        else
            s_cell = {sprintf('%s', Ystate)};
        end
        s = strjoin(s_cell, ',');
    end
end
