function [existsAttacker, witness] = exists_successful_attacker(GSJ, Qd, Qc)


existsAttacker = false;
witness = [];

T = GSJ{3};           % transitions [src, event, dst]
n = GSJ{1};           % number of states

% adjacency list
adj = cell(n,1);
for r = 1:size(T,1)
    s = T(r,1);
    t = T(r,3);
    adj{s}(end+1) = t; 
end

for q = find(Qd)'
    % ---------- reachable subgraph ----------
    R = reachable_states(adj, q);

    % ---------- build subgraph adjacency ----------
    subAdj = cell(n,1);
    for i = R
        subAdj{i} = adj{i}(ismember(adj{i}, R));
    end

    % ---------- SCC decomposition ----------
    sccs = tarjan_scc(subAdj, R);

    % ---------- check cycles ----------
    for k = 1:numel(sccs)
        C = sccs{k};

        hasCycle = numel(C) > 1 || ...
                   any(cellfun(@(v) ismember(v, C), ...
                       num2cell(subAdj{C(1)})));

        if ~hasCycle
            continue;
        end

        % not exclusively certain
        if any(~Qc(C))
            existsAttacker = true;
            witness = q;
            return;
        end
    end
end
end
