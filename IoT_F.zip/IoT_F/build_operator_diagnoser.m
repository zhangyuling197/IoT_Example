function G_opr = build_operator_diagnoser(Gdiag, Gn, Sigma_ins, Sigma_era, Sigma_o)


Td   = Gdiag.T;     
Y    = Gdiag.Y;
nd   = numel(Y);

% ---------- Build diagnoser delta ----------
delta = cell(nd,1);
for i = 1:nd
    delta{i} = containers.Map('KeyType','int32','ValueType','any');
end

for r = 1:size(Td,1)
    s = Td(r,1);
    a = Td(r,2);
    t = Td(r,3);
    % 只保留可观事件的映射
    if ~ismember(a, Sigma_o), continue; end
    key = int32(a);  % 1-based
    if ~isKey(delta{s}, key)
        delta{s}(key) = t;
    else
        delta{s}(key) = unique([delta{s}(key), t]);
    end
end

% ---------- Build Sigma ----------
Sigma = {};
% 原始可观事件
for k = Sigma_o
    Sigma{end+1} = Gn.Sigma{k};
end
no = numel(Sigma);

% 插入事件 e+ 自环
for e = Sigma_ins(:)'
    Sigma{end+1} = [Gn.Sigma{e} '+'];
end
n_plus = numel(Sigma_ins);

% 删除事件 a- 自环
for a = Sigma_era(:)'
    Sigma{end+1} = [Gn.Sigma{a} '-'];
end
n_minus = numel(Sigma_era);

sink = nd + 1;
T = [];

% ---------- Build transitions ----------
for q = 1:nd
    defined_syms = [];

    % ---- 原始 diagnoser可观事件 ----
    for k = 1:no
        sym_idx = k;
        key_orig = Sigma_o(k);  % 1-based
        if isKey(delta{q}, int32(key_orig))
            dsts = delta{q}(int32(key_orig));
            for d = dsts(:)'
                T(end+1,:) = [q, sym_idx, d];
            end
            defined_syms(end+1) = sym_idx;
        end
    end

    % ---- 插入事件 e+ ----
    for j = 1:n_plus
        e = Sigma_ins(j);
        sym_idx = no + j;
        key_orig = e;  % 1-based
        if isKey(delta{q}, int32(key_orig))
            dsts = delta{q}(int32(key_orig));
            for d = dsts(:)'
                T(end+1,:) = [q, sym_idx, d];
            end
        else
            T(end+1,:) = [q, sym_idx, sink];
        end
        defined_syms(end+1) = sym_idx;
    end

    % ---- 删除事件 a- 自环 ----
    for j = 1:n_minus
        sym_idx = no + n_plus + j;
        T(end+1,:) = [q, sym_idx, q];
        defined_syms(end+1) = sym_idx;
    end

    % ---- 未定义事件 -> sink ----
    all_syms = 1:(no+n_plus+n_minus);
    undefined_syms = setdiff(all_syms, defined_syms);
    for sym = undefined_syms
        T(end+1,:) = [q, sym, sink];
    end
end

% ---------- finalize ----------
G_opr.X     = 1:sink;
G_opr.X0    = Gdiag.X0;
G_opr.Y     = [Y, {'sink'}];
G_opr.Sigma = Sigma;  % |Sigma| = no+n_plus+n_minus
G_opr.T     = unique(T,'rows','stable');
G_opr.n     = sink;
G_opr.sink  = sink;
end
