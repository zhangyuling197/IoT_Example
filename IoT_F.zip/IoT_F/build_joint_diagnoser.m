function GJ = build_joint_diagnoser(G_att, G_opr)


% ---- unpack automata ----
[nA, EdA, TdA] = unpack_auto(G_att);
[nO, EdO, TdO] = unpack_auto(G_opr);

% ---- ensure Sigma cell array ----
EdA = ensure_cell_str(EdA);
EdO = ensure_cell_str(EdO);

% ---- joint Sigma = attacker Sigma ----
EdJ = EdA; nE = numel(EdJ);
s2iA = containers.Map(EdA, num2cell(1:nE));
s2iO = containers.Map(EdO, num2cell(1:numel(EdO)));
s2iJ = containers.Map(EdJ, num2cell(1:nE));

% ---- build delta maps ----
deltaA = build_delta(nA, TdA);
deltaO = build_delta(nO, TdO);

% ---- initial states ----
initA = 1; if isfield(G_att,'X0') && ~isempty(G_att.X0), initA = G_att.X0; end
initO = 1; if isfield(G_opr,'X0') && ~isempty(G_opr.X0), initO = G_opr.X0; end

% ---- BFS over reachable pairs ----
pair2idx = containers.Map(); keyfun = @(i,j) sprintf('%d#%d',i,j);
pair2idx(keyfun(initA,initO)) = 1;

queue = [initA, initO];
jointPairs = zeros(256,2); jointPairs(1,:) = [initA, initO];
nJ = 1; T = [];

while ~isempty(queue)
    ij = queue(1,:); queue(1,:) = [];
    i = ij(1); j = ij(2);

    for k = 1:nE
        sym = EdJ{k};

        % attacker must have transition
        if i <= numel(deltaA) && ~isempty(deltaA{i}) && isKey(deltaA{i},int32(s2iA(sym)))
            u = double(deltaA{i}(int32(s2iA(sym))));

            % operator transition
            if isKey(s2iO,sym)
                if j <= numel(deltaO) && ~isempty(deltaO{j}) && isKey(deltaO{j},int32(s2iO(sym)))
                    v = double(deltaO{j}(int32(s2iO(sym))));
                else
                    v = j; % stay
                end
            else
                continue; 
            end

            % add joint edge
            [nJ, pair2idx, queue, T, jointPairs] = add_edge(i,j,u,v,s2iJ(sym),nJ,pair2idx,queue,T,keyfun,jointPairs);
        end
    end
end

jointPairs = jointPairs(1:nJ,:);
GJ.X = 1:nJ;
GJ.Sigma = EdJ;
GJ.T = T;
GJ.init = [initA, initO];
GJ.jointMap = jointPairs;
GJ.pair2idx = pair2idx;
end

%% ---------------- helper functions ----------------

function Ed = ensure_cell_str(Ed)
if ischar(Ed), Ed = arrayfun(@(c){c}, Ed);
elseif isstring(Ed), Ed = cellstr(Ed);
end
end

function [n,Ed,Td] = unpack_auto(G)
n = numel(G.X); Ed = G.Sigma; Td = G.T;
end

function delta = build_delta(n, Td)
if isempty(Td), delta = cell(n,1); return; end
max_state = max(n, max(Td(:,1:3),[],'all'));
delta = cell(max_state,1);
for r=1:size(Td,1)
    s = double(Td(r,1)); a = double(Td(r,2)); t = double(Td(r,3));
    if isempty(delta{s}), delta{s} = containers.Map('KeyType','int32','ValueType','int32'); end
    delta{s}(int32(a)) = int32(t);
end
end

function [nJ, pair2idx, queue, T, jointPairs] = add_edge(i,j,u,v,symIdx,nJ,pair2idx,queue,T,keyfun,jointPairs)
k = keyfun(u,v);
if ~isKey(pair2idx,k)
    pair2idx(k) = nJ+1;
    queue(end+1,:) = [u,v];
    if size(jointPairs,1)<nJ+1, jointPairs = [jointPairs; zeros(max(256,size(jointPairs,1)),2)]; end
    jointPairs(nJ+1,:) = [u,v];
    nJ = nJ + 1;
end
src = pair2idx(keyfun(i,j));
dst = pair2idx(k);
T(end+1,:) = [src, symIdx, dst];
end