% ================= 1. NFA States and Events =================
Gn.X = 1:11;       % states 1~11
Gn.X0 = 1;         % initial state

% Events
Sigma = {'a','b','c','d','e','f','g','h','i','j','r'};
Gn.Sigma = Sigma;

% Transition table: [from, event_id, to]
Gn.T = [
    1, 1, 2;    % 1 --a--> 2
    1,11, 7;    % 1 --r--> 7
    1, 5, 7;    % 1 --e--> 7
    1, 8, 1;    % 1 --h--> 1
    1,10, 1;    % 1 --j--> 1

    2, 3, 3;    % 2 --c--> 3
    2, 8, 1;    % 2 --h--> 1

    3, 4, 4;    % 3 --d--> 4
    3, 7, 4;    % 3 --g--> 4

    4, 2, 8;    % 4 --b--> 8

    5, 6, 6;    % 5 --f--> 6

    6, 1, 3;    % 6 --a--> 3

    7, 9, 8;    % 7 --i--> 8
    7, 10, 1;   % 7 --j--> 1

    8, 7, 9;    % 8 --g--> 9

    9, 4,10;    % 9 --d-->10

   10, 6,11;   %10 --f-->11

   11,11,1;    %11 --r-->1
];

% ================= 2. Observable / Insert / Erase Events =================
Sigma_o   = find(ismember(Gn.Sigma, {'a','b','d','e','f','g','h','j','r'}));  % observable events
Sigma_ins = find(ismember(Gn.Sigma, {'e','j'}));                              % only e,j can be inserted
Sigma_era = find(ismember(Gn.Sigma, {'a','b','r','g','h'}));                  % only a,b,r,g,h can be erased

% Fault event
fault_event = find(strcmp(Gn.Sigma,'f'));

%% ================= 3. Build Diagnoser =================
Gdiag = NFA2Diagnoser(Gn, Sigma_o, fault_event);

%% ================= 4. Build Attacker Diagnoser =================

G_att = build_attacker_diagnoser(Gdiag, Gn, Sigma_o,Sigma_ins, Sigma_era);
%printAttackerDiagnoser(G_att, Gn);

G_opr = build_operator_diagnoser(Gdiag, Gn, Sigma_ins, Sigma_era, Sigma_o);
%printOperatorDiagnoser(G_opr);

GJ = build_joint_diagnoser(G_att, G_opr);
%printJointObserver(GJ, G_att, G_opr);
%printOperatorSinkStates(GJ, G_att, G_opr);

%% ================= Joint state classification =================
Sigma_o_idx   = find(ismember(GJ.Sigma, {'a','b','d','e'}));  % 可观测事件
Sigma_ins_idx = find(ismember(GJ.Sigma, {'e'}));              % 可插入事件
Sigma_era_idx = find(ismember(GJ.Sigma, {'a','b'}));          % 可擦除事件
[Qn, Qc, Qu, Q_sink, Qd, Qe, Qwe] = ComputeJointState(GJ, G_att, G_opr, Sigma_o_idx, Sigma_ins_idx, Sigma_era_idx);

%% ================= Prognosability =================
Ea = 1:numel(G_att.Sigma);
[isNotRobust, badCycle] = checkNotRobustPrognosable(GJ, Qc, Qd, Ea, G_att, G_opr);

if isNotRobust
    disp('G is NOT robustly prognosable.');
else
    disp('G is robustly prognosable.');
end

% ---- 1. joint-level operator-sink states (true sink) ----
Q_sink_idx = find(Q_sink);                      
sink_opr_list = unique(GJ.jointMap(Q_sink_idx,2));
Q_opr_sink_joint = find( ...
    ismember(GJ.jointMap(:,2), sink_opr_list) ...
);

% Qe = false(1, numel(GJ.X));
% Qe(Q_opr_sink_joint) = true;

% ================= Stealthy joint diagnoser =================

GSJ = build_stealthy_joint_diagnoser(GJ, GJ.jointMap, sink_opr_list, Sigma_o_idx, Sigma_ins_idx, Sigma_era_idx);
%printStealthyJoint(GSJ, G_att, G_opr);

% ================= Existence of Successful Attacker =================
[existsAttacker, witness] = exists_successful_attacker(GSJ, Qd, Qc);

if existsAttacker
    disp('There is a sucessful attacker.');
else
    disp('No sucessful attacker exist.');
end