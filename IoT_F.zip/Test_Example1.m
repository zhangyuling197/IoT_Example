clc; clear;

%% ================= NFA definition =================
Gn.X = 1:10;
Gn.X0 = 1;

Sigma = {'a','b','c','d','e','f'};

Gn.Sigma = Sigma;
%% ================= 2. Observable / Insert / Erase Events =================
Sigma_o   = find(ismember(Gn.Sigma, {'a','b','d','e'}));  % diagnoser observable
Sigma_ins = find(ismember(Gn.Sigma, {'e'}));              % only e can be inserted
Sigma_era = find(ismember(Gn.Sigma, {'a','b'}));          % only a,b can be erased
Gn.T = [
    % ---------- state 0 ----------
    1, 5, 2;    % 0 --e--> 1
    1, 3, 5;    % 0 --c--> 4   (dashed)
    1, 1, 4;    % 0 --a--> 3
    1, 2, 8;    % 0 --b--> 7

    % ---------- state 1 ----------
    2, 1, 3;    % 1 --a--> 2

    % ---------- state 2 ----------
    3, 4, 3;    % 2 --d--> 2 (self-loop)
    3, 3, 4;    % 2 --c--> 3   (dashed)

    % ---------- state 3 ----------
    4, 2, 8;    % 3 --b--> 7

    % ---------- state 4 ----------
    5, 5, 6;    % 4 --e--> 5

    % ---------- state 5 ----------
    6, 4, 7;    % 5 --d--> 6

    % ---------- state 6 ----------
    7, 2, 7;    % 6 --b--> 6 (self-loop)

    % ---------- state 7 ----------
    8, 4, 9;    % 7 --d--> 8

    % ---------- state 8 ----------
    9, 6, 10;   % 8 --f--> 9

    % ---------- state 9 ----------
    10, 2, 10;  % 9 --b--> 9 (self-loop)
];

fault_event = find(strcmp(Gn.Sigma,'f'));



%% ================= 3. Build Diagnoser =================
Gdiag = NFA2Diagnoser(Gn, Sigma_o, fault_event);

%% ================= 4. Build Attacker Diagnoser =================

G_att = build_attacker_diagnoser(Gdiag, Gn, Sigma_o,Sigma_ins, Sigma_era);
%printAttackerDiagnoser(G_att, Gn);

G_opr = build_operator_diagnoser(Gdiag, Gn, Sigma_ins, Sigma_era, Sigma_o);
%printOperatorDiagnoser(G_opr);

GJ = build_joint_diagnoser(G_att, G_opr);
%printJointObserver(GJ, G_att, G_opr);
%printOperatorSinkStates(GJ, G_att, G_opr);

%% ================= Joint state classification =================
Sigma_o_idx   = find(ismember(GJ.Sigma, {'a','b','d','e'}));  % 可观测事件
Sigma_ins_idx = find(ismember(GJ.Sigma, {'e'}));              % 可插入事件
Sigma_era_idx = find(ismember(GJ.Sigma, {'a','b'}));          % 可擦除事件
[Qn, Qc, Qu, Q_sink, Qd, Qe, Qwe] = ComputeJointState(GJ, G_att, G_opr, Sigma_o_idx, Sigma_ins_idx, Sigma_era_idx);

%% ================= Prognosability =================
Ea = 1:numel(G_att.Sigma);

[isNotRobust, badCycle] = checkNotRobustPrognosable(GJ, Qc, Qd, Ea, G_att, G_opr);


if isNotRobust
    disp('G is NOT robustly prognosable.');
else
    disp('G is robustly prognosable.');
end

% ---- 1. joint-level operator-sink states (true sink) ----
Q_sink_idx = find(Q_sink);                      
sink_opr_list = unique(GJ.jointMap(Q_sink_idx,2));
Q_opr_sink_joint = find( ...
    ismember(GJ.jointMap(:,2), sink_opr_list) ...
);


% ================= Stealthy joint diagnoser =================

GSJ = build_stealthy_joint_diagnoser(GJ, GJ.jointMap, sink_opr_list, Sigma_o_idx, Sigma_ins_idx, Sigma_era_idx);
%printStealthyJoint(GSJ, G_att, G_opr);

% ================= Existence of Successful Attacker =================
[existsAttacker, witness] = exists_successful_attacker(GSJ, Qd, Qc);

if existsAttacker
    disp('There is a sucessful attacker.');
else
    disp('No sucessful attacker exist.');
end