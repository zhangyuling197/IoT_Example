function sccs = tarjan_scc(adj, nodes)

index = 0;
stack = [];
onStack = false(1, numel(adj));
idx = zeros(1, numel(adj));
low = zeros(1, numel(adj));
sccs = {};

for v = nodes
    if idx(v) == 0
        strongconnect(v);
    end
end

    function strongconnect(v)
        index = index + 1;
        idx(v) = index;
        low(v) = index;
        stack(end+1) = v; %#ok<AGROW>
        onStack(v) = true;

        for w = adj{v}
            if idx(w) == 0
                strongconnect(w);
                low(v) = min(low(v), low(w));
            elseif onStack(w)
                low(v) = min(low(v), idx(w));
            end
        end

        if low(v) == idx(v)
            C = [];
            while true
                w = stack(end);
                stack(end) = [];
                onStack(w) = false;
                C(end+1) = w; %#ok<AGROW>
                if w == v, break; end
            end
            sccs{end+1} = C; %#ok<AGROW>
        end
    end
end
