function s = format_diagnoser_state(Yq)
% Robust formatter for diagnoser information states

labels = {};

% ===== case 1: struct (most common in diagnoser) =====
if isstruct(Yq)
    if isfield(Yq,'N')
        for x = Yq.N
            labels{end+1} = sprintf('%dN', x);
        end
    end
    if isfield(Yq,'F')
        for x = Yq.F
            labels{end+1} = sprintf('%dF', x);
        end
    end

% ===== case 2: cell {N_set, F_set} =====
elseif iscell(Yq) && numel(Yq) == 2 && isnumeric(Yq{1})
    for x = Yq{1}
        labels{end+1} = sprintf('%dN', x);
    end
    for x = Yq{2}
        labels{end+1} = sprintf('%dF', x);
    end

% ===== case 3: pure numeric (assume normal) =====
elseif isnumeric(Yq)
    for x = Yq
        labels{end+1} = sprintf('%dN', x);
    end
else
    s = '∅';
    return;
end

if isempty(labels)
    s = '∅';
else
    s = strjoin(labels, ',');
end
end
