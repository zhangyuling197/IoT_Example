function idx = findBelief(Y, y)

idx = 0;
y = sortrows(y);

for i = 1:length(Y)
    if isequal(sortrows(Y{i}), y)
        idx = i;
        return;
    end
end
end
