function R = reachable_states(adj, q0)
visited = false(1, numel(adj));
queue = q0;
visited(q0) = true;

while ~isempty(queue)
    v = queue(1);
    queue(1) = [];
    for u = adj{v}
        if ~visited(u)
            visited(u) = true;
            queue(end+1) = u; %#ok<AGROW>
        end
    end
end

R = find(visited);
end
