clc; clear;

%% ==================== 实验参数 ====================
num_examples = 20;          % 随机自动机个数
n_range = [20 30];          % 状态数范围
m_range = [6 10];            % 事件数范围（含 f）
p_obs = 0.5;                % 可观事件比例
p_ins = 0.3;                % 插入事件比例
p_era = 0.3;                % 删除事件比例

fprintf('=== Generating random NFAs ===\n');
Gn_list = generate_random_nfa_p2(num_examples, n_range, m_range, p_obs, p_ins, p_era, '');

%% ==================== 初始化统计 ====================
cnt_not_robust = 0;
cnt_robust     = 0;
cnt_attacker   = 0;
details = struct([]);

%% ==================== 批量实验 ====================
for e = 1:num_examples
    fprintf('\n===== Example %d =====\n', e);

    % ---- unpack Gn ----
    Gn_raw = Gn_list{e};
    n          = Gn_raw{1};
    Gn.Sigma   = Gn_raw{2};
    Gn.T       = Gn_raw{3};
    Gn.X       = 1:n;
    Gn.X0      = Gn_raw{4};
    Gn.Xm      = Gn_raw{5};

    Sigma_o_cell   = Gn_raw{6};
    Sigma_ins_cell = Gn_raw{7};
    Sigma_era_cell = Gn_raw{8};

    % ---- index conversion ----
    Sigma_o   = find(ismember(Gn.Sigma, Sigma_o_cell));
    Sigma_ins = find(ismember(Gn.Sigma, Sigma_ins_cell));
    Sigma_era = find(ismember(Gn.Sigma, Sigma_era_cell));

    fault_event = find(strcmp(Gn.Sigma,'f'));
    if isempty(fault_event)
        error('Fault event f not found.');
    end

    %% ---- diagnoser ----
    tStart = tic;
    Gdiag = NFA2Diagnoser(Gn, Sigma_o, fault_event);

    %% ---- attacker / operator diagnoser ----
    G_att = build_attacker_diagnoser(Gdiag, Gn, Sigma_o, Sigma_ins, Sigma_era);
    G_opr = build_operator_diagnoser(Gdiag, Gn, Sigma_ins, Sigma_era, Sigma_o);

    %% ---- joint diagnoser ----
    
    GJ = build_joint_diagnoser(G_att, G_opr);
    T_GJ = toc(tStart);

    %% ---- joint state分类 ----
     tStart = tic;
    Sigma_o_idx   = find(ismember(GJ.Sigma, Sigma_o_cell));
    Sigma_ins_idx = find(ismember(GJ.Sigma, strcat(Sigma_ins_cell,'+')));
    Sigma_era_idx = find(ismember(GJ.Sigma, strcat(Sigma_era_cell,'-')));

    [Qn, Qc, Qu, Q_sink, Qd, Qe, Qwe] = ...
        ComputeJointState(GJ, G_att, G_opr, ...
                          Sigma_o_idx, Sigma_ins_idx, Sigma_era_idx);

    %% ---- robust prognosability ----
    Ea = 1:numel(G_att.Sigma);
  
    [isNotRobust, badCycle] = ...
        checkNotRobustPrognosable(GJ, Qc, Qd, Ea, G_att, G_opr);
    T_R = toc(tStart);

    robustStr = 'Yes';
    if isNotRobust
        robustStr = 'No';
        cnt_not_robust = cnt_not_robust + 1;
    else
        cnt_robust = cnt_robust + 1;
    end
    disp(['Robustly prognosable: ', robustStr]);

    %% ---- stealthy joint diagnoser & attacker existence ----
    Q_sink_idx = find(Q_sink);
    sink_opr_list = unique(GJ.jointMap(Q_sink_idx,2));

    tStart = tic;
    GSJ = build_stealthy_joint_diagnoser( ...
        GJ, GJ.jointMap, sink_opr_list, ...
        Sigma_o_idx, Sigma_ins_idx, Sigma_era_idx);
    T_A = toc(tStart);

    existsAttacker = false;
    if ~isempty(GSJ) && GSJ{1} > 0
        [existsAttacker, witness] = exists_successful_attacker(GSJ, Qd, Qc);
        if existsAttacker
            cnt_attacker = cnt_attacker + 1;
        end
    end
    attackerStr = 'No';
    if existsAttacker
        attackerStr = 'Yes';
    end
    disp(['Successful attacker exists: ', attackerStr]);

    %% ---- 记录信息 ----
    details(e).isNotRobust    = isNotRobust;
    details(e).existsAttacker = existsAttacker;
    details(e).n              = n;
    details(e).m              = numel(Gn.Sigma);
    details(e).numT           = size(Gn.T,1);    
    details(e).Sigma_o        = Sigma_o_cell;
    details(e).Sigma_ins      = Sigma_ins_cell;
    details(e).Sigma_era      = Sigma_era_cell;
    details(e).numGJStates    = numel(GJ.X);
    details(e).T_GJ           = T_GJ;
    details(e).T_R            = T_R;
    details(e).numGSJStates   = GSJ{1};
    details(e).T_A            = T_A;

    %% ---- 打印每个例子统计 ----
    fprintf('NFA: |X|=%d, |Sigma|=%d, |T|=%d, |Sigma_o|=%d, |Sigma_ins|=%d, |Sigma_era|=%d\n', ...
        n, numel(Gn.Sigma), size(Gn.T,1), numel(Sigma_o), numel(Sigma_ins), numel(Sigma_era));
    fprintf('Joint Diagnoser: |X|=%d, T-GJ=%.4fs, Robust=%s, T-R=%.4fs\n', ...
        numel(GJ.X), T_GJ, robustStr, T_R);
    fprintf('Stealthy Joint Diagnoser: |X|=%d, Successful Attacker=%s, T-A=%.4fs\n', ...
        GSJ{1}, attackerStr, T_A);
end

%% ==================== 汇总表格 ====================
fprintf('\n\n===== Summary of All Examples =====\n');
fprintf('%5s | %5s | %6s | %6s | %8s | %10s | %10s | %10s | %10s | %10s | %10s | %10s | %10s | %10s\n', ...
    'Ex', '|X|', '|Sigma|', '|T|', '|Sigma_o|', '|Sigma_ins|', '|Sigma_era|', ...
    '|GJ_X|', 'T-GJ(s)', 'Robust', 'T-R(s)', '|GSJ_X|', 'Attacker', 'T-A(s)');
fprintf('%s\n', repmat('-',1,125));

for e = 1:num_examples
    n             = details(e).n;
    m             = details(e).m;
    numT          = details(e).numT;
    numSigma_o    = numel(details(e).Sigma_o);
    numSigma_ins  = numel(details(e).Sigma_ins);
    numSigma_era  = numel(details(e).Sigma_era);
    numGJ_X       = details(e).numGJStates;
    T_GJ          = details(e).T_GJ;
    T_R           = details(e).T_R;
    numGSJ_X      = details(e).numGSJStates;
    T_A           = details(e).T_A;

    robustStr     = 'Yes'; if details(e).isNotRobust, robustStr = 'No'; end
    attackerStr   = 'No';  if details(e).existsAttacker, attackerStr = 'Yes'; end

    fprintf('%5d | %5d | %6d | %6d | %8d | %10d | %10d | %10d | %10.4f | %10s | %10.4f | %10d | %10s | %10.4f\n', ...
        e, n, m, numT, numSigma_o, numSigma_ins, numSigma_era, ...
        numGJ_X, T_GJ, robustStr, T_R, numGSJ_X, attackerStr, T_A);
end
%% ==================== 导出 Excel ====================

Ex          = (1:num_examples)';
X_size      = zeros(num_examples,1);
Sigma_size  = zeros(num_examples,1);
T_size      = zeros(num_examples,1);
Sigma_o_sz  = zeros(num_examples,1);
Sigma_ins_sz= zeros(num_examples,1);
Sigma_era_sz= zeros(num_examples,1);
GJ_X_size   = zeros(num_examples,1);
T_GJ        = zeros(num_examples,1);
Robust      = strings(num_examples,1);
T_R         = zeros(num_examples,1);
GSJ_X_size  = zeros(num_examples,1);
Attacker    = strings(num_examples,1);
T_A         = zeros(num_examples,1);

for e = 1:num_examples
    X_size(e)        = details(e).n;
    Sigma_size(e)    = details(e).m;
    T_size(e)        = details(e).numT;
    Sigma_o_sz(e)    = numel(details(e).Sigma_o);
    Sigma_ins_sz(e)  = numel(details(e).Sigma_ins);
    Sigma_era_sz(e)  = numel(details(e).Sigma_era);

   GJ_X_size(e)     = details(e).numGJStates;
T_GJ(e)          = details(e).T_GJ;

if details(e).isNotRobust
    Robust(e) = "No";
else
    Robust(e) = "Yes";
end
T_R(e) = details(e).T_R;

GSJ_X_size(e) = details(e).numGSJStates;

if details(e).existsAttacker
    Attacker(e) = "Yes";
else
    Attacker(e) = "No";
end
T_A(e) = details(e).T_A;

end

SummaryTable = table( ...
    Ex, X_size, Sigma_size, T_size, ...
    Sigma_o_sz, Sigma_ins_sz, Sigma_era_sz, ...
    GJ_X_size, T_GJ, Robust, T_R, ...
    GSJ_X_size, Attacker, T_A, ...
    'VariableNames', { ...
        'Ex', 'X', 'Sigma', 'T', ...
        'Sigma_o', 'Sigma_ins', 'Sigma_era', ...
        'GJ_X', 'T_GJ_s', 'Robust', 'T_R_s', ...
        'GSJ_X', 'Attacker', 'T_A_s' ...
    });

% filename = ['Summary_', datestr(now,'yyyymmdd_HHMMSS'), '.xlsx'];
% writetable(SummaryTable, filename);
% 
% fprintf('\nSummary table saved to Excel file:\n%s\n', filename);
